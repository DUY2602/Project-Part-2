<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once "settings.php"; // Database connection settings

// Function to sanitize input
function clean_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

 // Check if EOI table exists, if not, create it
 $createTableQuery = "CREATE TABLE IF NOT EXISTS eoi (
    EOInumber INT AUTO_INCREMENT PRIMARY KEY,
    job_RN VARCHAR(5) NOT NULL,
    first_name VARCHAR(20) NOT NULL,
    last_name VARCHAR(20) NOT NULL,
    dob DATE NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    street VARCHAR(40) NOT NULL,
    suburb VARCHAR(40) NOT NULL,
    state ENUM('VIC','NSW','QLD','NT','WA','SA','TAS','ACT') NOT NULL,
    postcode CHAR(4) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(12) NOT NULL,
    skills Text,

    otherSkills TEXT,
    status ENUM('New', 'Current', 'Final') DEFAULT 'New'
)";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dbconn = @mysqli_connect($host, $user, $password, $database);

    if (!$dbconn) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    // Check if EOI table exists, if not, create it
    $createTableQuery = "CREATE TABLE IF NOT EXISTS eoi (
        EOInumber INT AUTO_INCREMENT PRIMARY KEY,
        job_RN VARCHAR(5) NOT NULL,
        first_name VARCHAR(20) NOT NULL,
        last_name VARCHAR(20) NOT NULL,
        dob DATE NOT NULL,
        gender ENUM('Male', 'Female', 'Other') NOT NULL,
        street VARCHAR(40) NOT NULL,
        suburb VARCHAR(40) NOT NULL,
        state ENUM('VIC','NSW','QLD','NT','WA','SA','TAS','ACT') NOT NULL,
        postcode CHAR(4) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone VARCHAR(12) NOT NULL,
        skills Text,

        otherSkills TEXT,
        status ENUM('New', 'Current', 'Final') DEFAULT 'New'
    )";
    
    mysqli_query($dbconn, $createTableQuery);

    // Retrieve form data & sanitize
    $job_RN = clean_input($_POST['job_RN']);
    $first_name = clean_input($_POST['first_name']);
    $last_name = clean_input($_POST['last_name']);
    $dob = clean_input($_POST['dob']);
    $gender = clean_input($_POST['gender']);
    $street = clean_input($_POST['street']);
    $suburb = clean_input($_POST['suburb']);
    $state = clean_input($_POST['state']);
    $postcode = clean_input($_POST['postcode']);
    $email = filter_var(clean_input($_POST['email']), FILTER_VALIDATE_EMAIL);
    $phone = clean_input($_POST['phone']);
    $skills = (!empty($_POST['skills']) && is_array($_POST['skills'])) ? implode(", ", $_POST['skills']) : '';

    $otherSkills = isset($_POST['otherSkills']) ? clean_input($_POST['otherSkills']) : '';

  
    // Validate required fields
    if (empty($job_RN) || empty($first_name) || empty($last_name) || empty($dob) || empty($gender) ||
        empty($street) || empty($suburb) || empty($state) || empty($postcode) || empty($email) || empty($phone)) {
        die("Error: All required fields must be filled.");
    }

    // Validate job reference (exactly 5 alphanumeric characters)
    if (!preg_match("/^[A-Za-z0-9]{5}$/", $job_RN)) {
        die("Error: Job reference must be exactly 5 alphanumeric characters.");
    }

    // Validate date of birth (between 15 and 80 years old)
    if (!empty($_POST['dob']) && preg_match("/^\d{4}-\d{2}-\d{2}$/", $_POST['dob'])) {
        $dob = $_POST['dob'];
        $age = date_diff(date_create($dob), date_create('today'))->y;
        if ($age < 15 || $age > 80) {
            die("Error: Age must be between 15 and 80.");
        }
    } else {
        die("Error: Invalid date format. Please use YYYY-MM-DD.");
    }
    

    // Validate postcode based on state (assuming a function check_postcode_state exists)
    if (!preg_match("/^\d{4}$/", $postcode)) {
        die("Error: Postcode must be exactly 4 digits.");
    }

    // Insert into database
    $query = "INSERT INTO eoi (job_RN, first_name, last_name, dob, gender, street, suburb, state, postcode, email, phone, skills, otherSkills)
          VALUES ('$job_RN', '$first_name', '$last_name', '$dob', '$gender', '$street', '$suburb', '$state', '$postcode', '$email', '$phone', '$skills', '$otherSkills')";

    if (mysqli_query($dbconn, $query)) {
        $eoiNumber = mysqli_insert_id($dbconn); // Get the auto-generated EOInumber
        echo "<p>Thank you! Your application has been received. Your EOI number is <strong>$eoiNumber</strong>.</p>";
    } else {
        echo "<p>Error: Could not submit application. " . mysqli_error($dbconn) . "</p>";
    }

    mysqli_close($dbconn);
} else {
    // Redirect to prevent direct access
    header("Location: apply.php");
    exit();
}
?>
