<?php
$host = "feenix-mariadb.swin.edu.au";
$user = "s105553910";
$password = "240806";
$database = "s105553910_db";

?>
