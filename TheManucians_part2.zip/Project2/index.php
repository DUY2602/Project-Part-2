<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="styles/images/site-logo.png">
    <link rel="stylesheet" href="styles/style.css">
    <title>Home</title>
</head>
<body>
    
    <?php include "header.inc"; ?>
    
    <main>
    <div class="banner">
        <p>We, the Manucians, help skilled programmers secure their dream IT job and kickstart their career!</p>
        <a href="about.php"><button id="button">About Us</button></a>
    </div>
    
    <div class="container">
        <div class="box" id="box1">
            <img src="styles/images/soft-dev.jpg" id="img1" alt="Appetizer">
            <div class="text">
                <h2>Effective Job Listings</h2><br><br>
                <p>We recommend a wide range of jobs in different IT sectors, help you to choose the one that fits your skills and desire</p><br>
                <a href="jobs.php"><button class="btn">View Job list</button></a></div></div>
        
        <?php
        echo '<div class="box" id="box2">';


        echo '<div id="box21">';
        echo '<img src="styles/images/soft-dev.jpg">';
        echo '<h2>Data Scientist</h2>';
        echo '<p>Currently in large demand!!!</p>';
        echo '<a href="apply.php?id=DS202 & title=Data Scientist">';
        echo '<button class="btn">Apply Now</button>';
        echo '</a>';
        echo '</div>';


        echo '<div id="box22">';
        echo '<img src="styles/images/DevOps-index.jpg">';
        echo '<h2>DevOps Engineer</h2>';
        echo '<p>Currently in large demand!!!</p>';
        echo '<a href="apply.php?id=DO201 & title=DevOps Engineer">';
        echo '<button class="btn">Apply Now</button>';
        echo '</a>';
        echo '</div>';


        echo '<div id="box23">';
        echo '<img src="styles/images/full-stack-index.jpeg">';
        echo '<h2>Full Stack Developer</h2>';
        echo '<p>Currently in large demand!!!</p>';
        echo '<a href="apply.php?id=FS303 & title=Full Stack Developer">';
        echo '<button class="btn">Apply Now</button>';
        echo '</a>';
        echo '</div>';
        ?>


            <div id="caret"><a href="jobs.php"><i class="fa fa-caret-right" title="Read More"></i></a></div>
        </div>
    


        <div class="box" id="box3">
            <img src="styles/images/dev-community.jpg" alt="Community">
            <div class="text">
                <h2>Professional Community</h2><br><br>
                <p>Connect to developers all over the world to share data, to help each other and to expand your career relationship</p><br>
                <a href="about.php"><button class="button">About Us</button></a></div>
            </div>>
    </div>
    </main>

    <?php include "footer.inc"; ?>

</body>
</html>