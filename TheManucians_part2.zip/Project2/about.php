<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="styles/images/site-logo.png">
    <link rel="stylesheet" href="styles/style.css">
    <title>About Us</title>
</head>
<body>
    <?php include "header.inc"; ?>

    <main>
    <div class="member">
            <div id="box1">
                <img src="styles/images/bi.PNG" id="dessert" alt="Dessert">
                <h2>Nguyễn Đồng Khánh</h2>
                <p>ID: 105553910</p>
                <p>Adding records to EOI</p>
                <a href="mailto:105553910@student.swin.edu.au"><button class="btn">Contact Now</button></a>
            </div>
            <div id="box2">
                <img src="styles/images/duy.PNG" id="dessert" alt="Dessert">
                <h2>Đỗ Đức Duy</h2>
                <p>ID: 105550034</p>
                <p>Create .inc files, settings and jobs.php</p>
                <a href="mailto:105550034@student.swin.edu.au"><button class="btn">Contact Now</button></a>
            </div>
            <div id="box3">
                <img src="styles/images/dang.jpg" id="dessert" alt="Dessert">
                <h2>Nguyễn Hải Đăng</h2>
                <p>ID: 105305590</p>
                <p>Create database for Job Listings page</p>
                <a href="mailto:105305590@student.swin.edu.au"><button class="btn">Contact Now</button></a>
            </div>
            <div id="box4">
                <img src="styles/images/khang.PNG" id="dessert" alt="Dessert">
                <h2>Bùi Hoàng Nguyên Khang</h2>
                <p>ID: 105709975</p>
                <p>Do the enhancement and create EOI</p>
                <a href="mailto:105709975@student.swin.edu.au"><button class="btn">Contact Now</button></a>
            </div>
    </div>  

    <div class="group">
        <img src="styles/images/site-logo.png" alt="The Manucians">
        <div class="text">
            <h1>Name: The Manucians</h1><br><br>
            <h2>Tutor's name: Trung Nguyen</h2>
            <h3>Timetable:</h3>
            <table>
                <tr>
                    <th></th>
                    <th>Mon</th>
                    <th>Tue</th>
                    <th>Wed</th>
                    <th>Thu</th>
                    <th>Fri</th>
                    <th>Sat</th>
                    <th>Sun</th>
                </tr>

                <tr>
                    <td>Morning</td>
                    <td></td>
                    <td>On campus</td>
                    <td></td>
                    <td>Individual work</td>
                    <td></td>
                    <td></td>
                    <td>9:00 - 12:00 (GG meet)</td>
                </tr>

                <tr>
                    <td>Afternoon</td>
                    <td>13:00 - 17:00 (On campus)</td>
                    <td></td>
                    <td></td>
                    <td>Individual work</td>
                    <td></td>
                    <td>Check progress</td>
                    <td></td>
                </tr>
            </table>
        </div>
    </div>
    </main>

    <?php include "footer.inc"; ?>

</body>
</html>