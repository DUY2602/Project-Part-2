const container = document.querySelector(".container");
const chatsContainer = document.querySelector(".chats-container");
const promptForm = document.querySelector(".prompt-form");
const promptInput = promptForm.querySelector(".prompt-input");

const API_KEY = "AIzaSyD2D0wk3k_DqGxk5HteGIuO5pRCE4B5Ieo"; 
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${API_KEY}`;

let botMessage = "";
let chatHistory = []; 

const createMsgElement = (content, ...classes) => {
    const div = document.createElement("div");
    div.classList.add("message", ...classes);
    div.innerHTML = content;
    return div;
};

const scrollToBottom = () => container.scrollTo({ top: container.scrollHeight, behavior: "smooth" });

const typingEffect = (text, textElement, botMsgDiv) => {
    textElement.textContent = "";
    const words = text.split(" ");
    let wordIndex = 0;

    const typingInterval = setInterval(() => {
        if (wordIndex < words.length) {
            textElement.textContent += (wordIndex === 0 ? "" : " ") + words[wordIndex++];
            botMsgDiv.classList.remove("loading");
            scrollToBottom();
        } else {
            clearInterval(typingInterval);
        }
    }, 40);
};

const generateResponse = async (botMsgDiv) => {
    const textElement = botMsgDiv.querySelector(".message-text");

    try {
        const response = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ contents: chatHistory })
        });
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.error.message);
        }

        const responseText = data.candidates[0].content.parts[0].text.replace(/\*\*([^*]+)\*\*/g, "$1").trim();
        typingEffect(responseText, textElement, botMsgDiv);

    } catch (error) {
        console.error("Error:", error);

    } finally {
        chatHistory = []; 
    }
};

const handleFormSubmit = (e) => {
    e.preventDefault();
    let userMessage = promptInput.value.trim(); 

    if (!userMessage) return;

    promptInput.value = "";

    container.classList.add("sent");

    const userMsgHTML = `<p class="message-text"></p>`;
    const userMsgDiv = createMsgElement(userMsgHTML, "user-message");

    userMsgDiv.querySelector(".message-text").textContent = userMessage;
    chatsContainer.appendChild(userMsgDiv);
    scrollToBottom();

    chatHistory.push({ role: "user", parts: [{ text: userMessage }] }); 

    setTimeout(() => {
        const botMsgHTML = `<img src="images/site-logo.png" class="avatar"><p class="message-text">Just a sec...</p>`;
        const botMsgDiv = createMsgElement(botMsgHTML, "bot-message", "loading");

        chatsContainer.appendChild(botMsgDiv);
        scrollToBottom();
        generateResponse(botMsgDiv);
    }, 600);
};

promptForm.addEventListener("submit", handleFormSubmit);

const suggestionItems = document.querySelectorAll(".suggestions-item");

suggestionItems.forEach(item => {
  item.addEventListener("click", () => {
    const suggestionText = item.querySelector(".text").textContent;
    
    promptInput.value = suggestionText;
    
    const submitEvent = new Event("submit", { bubbles: true, cancelable: true });
    promptForm.dispatchEvent(submitEvent);
  });
});