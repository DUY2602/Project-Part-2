<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "settings.php"; // Database connection settings

// Connect to database
$dbconn = @mysqli_connect($host, $user, $password, $database);
if (!$dbconn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Handle delete single EOI
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete"])) {
        $eoi_number = $_POST["delete"];

        // Prepare and execute the delete query
        $deleteQuery = "DELETE FROM eoi WHERE EOInumber = ?";
        $stmt = mysqli_prepare($dbconn, $deleteQuery);
        mysqli_stmt_bind_param($stmt, "i", $eoi_number);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        echo "<p>EOI <strong>$eoi_number</strong> has been deleted.</p>";
    
}

// Handle DELETE_ALL request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete_all"])) {
    if (!empty($_POST["delete_job_RN"])) { // Check if input is filled
        $job_RN = $_POST["delete_job_RN"];

        // Prepare and execute the delete query
        $deleteQuery = "DELETE FROM eoi WHERE job_RN = ?";
        $stmt = mysqli_prepare($dbconn, $deleteQuery);
        mysqli_stmt_bind_param($stmt, "s", $job_RN);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        echo "<p>All EOIs for Job Reference <strong>$job_RN</strong> have been deleted.</p>";
    } 
}

// Handle Bulk Update for Other Skills & Status
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update_all"])) {
    if (isset($_POST["EOINumber"]) && isset($_POST["otherSkills"]) && isset($_POST["status"])) {
        foreach ($_POST["EOINumber"] as $index => $EOINumber) {
            $new_other = $_POST["otherSkills"][$index];
            $new_status = $_POST["status"][$index];

            $updateQuery = "UPDATE eoi SET otherSkills = ?, status = ? WHERE EOInumber = ?";
            $stmt = mysqli_prepare($dbconn, $updateQuery);
            mysqli_stmt_bind_param($stmt, "ssi", $new_other, $new_status, $EOINumber);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
        echo "<p>All records updated successfully!</p>";
    }
}

// Search Filters
$searchQuery = "SELECT * FROM eoi";
$whereClauses = [];

if (!empty($_GET["job_RN"])) {
    $whereClauses[] = "job_RN = '" . mysqli_real_escape_string($dbconn, $_GET["job_RN"]) . "'";
}

if (!empty($_GET["first_name"])) {
    $whereClauses[] = "first_name LIKE '%" . mysqli_real_escape_string($dbconn, $_GET["first_name"]) . "%'";
}

if (!empty($_GET["last_name"])) {
    $whereClauses[] = "last_name LIKE '%" . mysqli_real_escape_string($dbconn, $_GET["last_name"]) . "%'";
}

if (!empty($whereClauses)) {
    $searchQuery .= " WHERE " . implode(" AND ", $whereClauses);
}
// SELECT * FROM eoi WHERE job_RN = 'FE101' AND first_name LIKE '%John%'

$result = mysqli_query($dbconn, $searchQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage EOIs</title>
    <link rel="stylesheet" href="styles/style.css">
</head>
<body id="manage_database">
<h1>HR Manager - Manage EOIs</h1>

<form method="GET" action="manage.php">
    <label>Job Reference:</label>
    <input type="text" name="job_RN" id="text_filter" value="<?= isset($_GET["job_RN"]) ? htmlspecialchars($_GET["job_RN"]) : '' ?>">

    <label>First Name:</label>
    <input type="text" name="first_name" id="text_filter" value="<?= isset($_GET["first_name"]) ? htmlspecialchars($_GET["first_name"]) : '' ?>">

    <label>Last Name:</label>
    <input type="text" name="last_name" id="text_filter" value="<?= isset($_GET["last_name"]) ? htmlspecialchars($_GET["last_name"]) : '' ?>"> 

    <hr>
    <button type="submit">Search</button>
</form>


<!-- Search Form -->
<form method="POST" action="manage.php">
    <table border="1">
        <tr>
            <th>EOI Number</th>
            <th>Job Ref</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Skills</th> 
            <th>Other Skills</th> 
            <th>Status</th>
            <th>Delete</th>
        </tr>

        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row["EOInumber"] ?></td>
                <td><?= htmlspecialchars($row["job_RN"]) ?></td>
                <td><?= htmlspecialchars($row["first_name"]) ?></td>
                <td><?= htmlspecialchars($row["last_name"]) ?></td>
                <td><?= htmlspecialchars($row["email"]) ?></td>
                <td><?= htmlspecialchars($row["phone"]) ?></td>
                <td><?= htmlspecialchars($row["skills"]) ?></td> 

                <!-- Other Skills Input -->
                <td>
                    <input type="hidden" name="EOINumber[]" value="<?= $row["EOInumber"] ?>"> 
                    <input type="text" name="otherSkills[]" value="<?= htmlspecialchars($row["otherSkills"]) ?>"> 
                </td>

                <!-- Status Dropdown -->
                <td>
                    <select name="status[]">
                        <option value="New" <?= $row["status"] == "New" ? "selected" : "" ?>>New</option>
                        <option value="Current" <?= $row["status"] == "Current" ? "selected" : "" ?>>Current</option>
                        <option value="Final" <?= $row["status"] == "Final" ? "selected" : "" ?>>Final</option>
                    </select>
                </td>

                <!-- Delete Button -->
                <td>
                    <button type="submit" name="delete" value="<?= $row["EOInumber"] ?>" onclick="return confirm('Are you sure?')">Delete</button>
                </td>
            </tr>
        <?php } ?>
    </table>

    <br>
    <button type="submit" name="update_all">Apply</button>
</form>

<form method="POST" action="manage.php" onsubmit="return confirm('Are you sure you want to delete all EOIs for this job reference?');">
    <label>Delete all EOIs for Job Reference:</label>
    <input type="text" name="delete_job_RN" placeholder="Please enter Job Reference you want to delete"  required >
    <button type="submit" name="delete_all">Delete All</button>
</form>



<?php mysqli_close($dbconn); ?>
</body>
</html>
