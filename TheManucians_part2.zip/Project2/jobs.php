<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="styles/images/site-logo.png">
    <link rel="stylesheet" href="styles/style.css">
    <title>Job Listings</title>
</head>
<body>

<?php 
    require_once "settings.php"; 
    $dbconn = @mysqli_connect($host, $user, $password, $database);

    $sql = "SELECT title, description, salary, position, responsibilities, qualifications, path, id FROM prediction";
    $result = mysqli_query($dbconn, $sql);

    $jobs = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $jobs[] = $row;
    }
    mysqli_close($dbconn);

    $totalJobs = count($jobs);
?>

<?php include "header.inc"; ?>
<main>

    <div class="banner">
        <p>Don't hesitate to apply for a job!</p>
    </div>
    
    <div class="job_list_page">
        <div class="container">

            <section class="box" id="box_job">
                <?php 
                for ($i = 0; $i < min(3, $totalJobs); $i++) {
                    echo '<div id="box1_' . ($i + 1) . '">';
                    echo '<img src="' . htmlspecialchars($jobs[$i]['path']) . '" alt="' . htmlspecialchars($jobs[$i]['title']) . '">';
                    echo '<h2>' . htmlspecialchars($jobs[$i]['title']) . '</h2>';
                    echo '<p><strong>ID:</strong> ' . htmlspecialchars($jobs[$i]['id']) . '</p>';
                    echo '<p><strong>Description:</strong> ' . htmlspecialchars($jobs[$i]['description']) . '</p>';
                    echo '<p><strong>Salary:</strong> $' . number_format($jobs[$i]['salary']) . '</p>';
                    echo '<p><strong>Reports to:</strong> ' . htmlspecialchars($jobs[$i]['position']) . '</p>';
                    echo '<p><strong>Skills:</strong> ' . htmlspecialchars($jobs[$i]['responsibilities']) . '</p>';
                    echo '<p><strong>Requirements:</strong> ' . htmlspecialchars($jobs[$i]['qualifications']) . '</p>';
                    echo '<a href="apply.php?id=' . urlencode($jobs[$i]['id']) . '&title=' . urlencode($jobs[$i]['title']) . '">';
                    echo '<button class="btn">Apply Now</button>';
                    echo '</a>';


                    echo '</div>';
                }
                ?>
            </section>

            <section class="box" id="box_job2">
                <?php 
                for ($i = 3; $i < min(6, $totalJobs); $i++) {
                    echo '<div id="box2_' . ($i - 2) . '">';
                    echo '<img src="' . htmlspecialchars($jobs[$i]['path']) . '" alt="' . htmlspecialchars($jobs[$i]['title']) . '">';
                    echo '<h2>' . htmlspecialchars($jobs[$i]['title']) . '</h2>';
                    echo '<p><strong>ID:</strong> ' . htmlspecialchars($jobs[$i]['id']) . '</p>';
                    echo '<p><strong>Description:</strong> ' . htmlspecialchars($jobs[$i]['description']) . '</p>';
                    echo '<p><strong>Salary:</strong> $' . number_format($jobs[$i]['salary']) . '</p>';
                    echo '<p><strong>Reports to:</strong> ' . htmlspecialchars($jobs[$i]['position']) . '</p>';
                    echo '<p><strong>Skills:</strong> ' . htmlspecialchars($jobs[$i]['responsibilities']) . '</p>';
                    echo '<p><strong>Requirements:</strong> ' . htmlspecialchars($jobs[$i]['qualifications']) . '</p>';
                    echo '<a href="apply.php?id=' . urlencode($jobs[$i]['id']) . '">';
                    echo '<button class="btn">Apply Now</button>';
                    echo '</a>';

                    echo '</div>';
                }
                ?>
            </section>

            <section class="box" id="box3">
                <?php 
                for ($i = 6; $i < min(9, $totalJobs); $i++) {
                    echo '<div id="box3_' . ($i - 5) . '">';
                    echo '<img src="' . htmlspecialchars($jobs[$i]['path']) . '" alt="' . htmlspecialchars($jobs[$i]['title']) . '">';
                    echo '<h2>' . htmlspecialchars($jobs[$i]['title']) . '</h2>';
                    echo '<p><strong>ID:</strong> ' . htmlspecialchars($jobs[$i]['id']) . '</p>';
                    echo '<p><strong>Description:</strong> ' . htmlspecialchars($jobs[$i]['description']) . '</p>';
                    echo '<p><strong>Salary:</strong> $' . number_format($jobs[$i]['salary']) . '</p>';
                    echo '<p><strong>Reports to:</strong> ' . htmlspecialchars($jobs[$i]['position']) . '</p>';
                    echo '<p><strong>Skills:</strong> ' . htmlspecialchars($jobs[$i]['responsibilities']) . '</p>';
                    echo '<p><strong>Requirements:</strong> ' . htmlspecialchars($jobs[$i]['qualifications']) . '</p>';
                    echo '<a href="apply.php?id=' . urlencode($jobs[$i]['id']) . '">';
                    echo '<button class="btn">Apply Now</button>';
                    echo '</a>';

                    echo '</div>';
                }
                ?>
            </section>

        </div>

        <aside class="job-sidebar">
            <img src="styles/images/aside1.png" alt="Career growth illustration">
        </aside>

    </div>
</main>
        
<?php include "footer.inc"; ?>

</body>
</html>
