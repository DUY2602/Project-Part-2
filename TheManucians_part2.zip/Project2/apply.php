<?php
require_once "settings.php";

// Connect to the database
$dbconn = @mysqli_connect($host, $user, $password, $database);

if (!$dbconn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Initialize job variables
$job_id = isset($_GET['id']) ? $_GET['id'] : null;
$job_title = "General Application"; // Default title
$job_reference = ""; // Default reference number

if ($job_id) {
    // Fetch job details based on ID
    $sql = "SELECT title FROM prediction WHERE id = ?";
    $stmt = mysqli_prepare($dbconn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $job_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $job_title = $row['title'];
        $job_reference = htmlspecialchars($job_id);
    }

    mysqli_stmt_close($stmt);
}

// Close the database connection
mysqli_close($dbconn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="styles/images/site-logo.png">
    <title>Job Application</title>
    <link rel="stylesheet" href="styles/style.css">
</head>
<body class="apply_body">

<?php include "header.inc"; ?>

<main>
    <form class="apply_form" action="process_eoi.php" method="post">
        <h2>Applying for: <?= htmlspecialchars($job_title) ?></h2> 

        <!-- Job Reference Number -->
        <label for="job_RN">Job Reference Number:</label>
        <select id="job_RN" name="job_RN" value="<?= $job_reference ?>" required>
        <option value="">Select...</option>
        <option value="FE101" <?= ($job_reference == "FE101") ? "selected" : "" ?>>FE101</option>
        <option value="BE102" <?= ($job_reference == "BE102") ? "selected" : "" ?>>BE102</option>
        <option value="DE103" <?= ($job_reference == "DE103") ? "selected" : "" ?>>DE103</option>
        <option value="DO201" <?= ($job_reference == "DO201") ? "selected" : "" ?>>DO201</option>
        <option value="DS202" <?= ($job_reference == "DS202") ? "selected" : "" ?>>DS202</option>
        <option value="PM203" <?= ($job_reference == "PM203") ? "selected" : "" ?>>PM203</option>
        <option value="QC301" <?= ($job_reference == "QC301") ? "selected" : "" ?>>QC301</option>
        <option value="AE302" <?= ($job_reference == "AE302") ? "selected" : "" ?>>AE302</option>
        <option value="FS303" <?= ($job_reference == "FS303") ? "selected" : "" ?>>FS303</option>
        </select>
        <br>

        <!-- First Name -->
        <label for="first_name">First Name:</label>
        <input type="text" id="first_name" name="first_name" maxlength="20" pattern="[A-Za-z]+" required>
        <br>

        <!-- Last Name -->
        <label for="last_name">Last Name:</label>
<input type="text" id="last_name" name="last_name" maxlength="20" pattern="[A-Za-z]+" required>
        <br>

        <!-- Date of Birth -->
        <label for="dob">Date of Birth:</label>
        <input type="date" id="dob" name="dob" required>
        <br>

        <!-- Gender -->
        <fieldset>
            <legend class="legend">Gender:</legend>
            <input type="radio" id="Male" name="gender" value="Male" required>
            <label for="Male">Male</label>
            <input type="radio" id="Female" name="gender" value="Female" required>
            <label for="Female">Female</label>
            <input type="radio" id="Other" name="gender" value="Other" required>
            <label for="Other">Other</label>
        </fieldset>
        <br>

        <!-- Address -->
        <label for="street">Street Address:</label>
        <input type="text" id="street" name="street" maxlength="40" required>
        <br>

        <label for="suburb">Suburb/Town:</label>
        <input type="text" id="suburb" name="suburb" maxlength="40" required>
        <br>

        <!-- State Dropdown -->
        <label for="state">State:</label>
        <select id="state" name="state" required>
            <option value="">Select...</option>
            <option value="VIC">VIC</option>
            <option value="NSW">NSW</option>
            <option value="QLD">QLD</option>
            <option value="NT">NT</option>
            <option value="WA">WA</option>
            <option value="SA">SA</option>
            <option value="TAS">TAS</option>
            <option value="ACT">ACT</option>
        </select>
        <br>

        <!-- Postcode -->
        <label for="postcode">Postcode:</label>
        <input type="text" id="postcode" name="postcode" pattern="\d{4}" required>
        <br>

        <!-- Email -->
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <br>

        <!-- Phone Number -->
        <label for="phone">Phone Number:</label>
        <input type="text" id="phone" name="phone" pattern="[0-9 ]{8,12}" required>
        <br>

        <!-- Skills -->
        <fieldset>
            <legend class="legend">Skills:</legend>
            <input type="checkbox" id="html" name="skills[]" value="HTML">
            <label for="html">HTML</label>
            <input type="checkbox" id="css" name="skills[]" value="CSS">
            <label for="css">CSS</label>
            <input type="checkbox" id="js" name="skills[]" value="JavaScript">
            <label for="js">JavaScript</label>
            <input type="checkbox" id="python" name="skills[]" value="Python">
            <label for="python">Python</label>
        </fieldset>
        <br>

        <!-- Other Skills Textarea -->
        <label for="other">Other Skills:</label>
        <textarea id="other" name="other" rows="4" cols="30"></textarea>
        <br>

        <!-- Submit Button -->
        <button id="submit-btn" type="submit">Apply</button>
        </form>
</main>

<?php include "footer.inc"; ?>

</body>
</html>