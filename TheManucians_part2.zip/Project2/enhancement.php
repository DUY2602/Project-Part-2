<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enhancement</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="images/site-logo.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="styles/style.css">
</head>
<body id="enhancement">
    <?php include 'header.inc';?>

<main>
    <div class="container">
        <header class="app-header">
            <h1 class="heading">Hello, there</h1>   
            <h2 class="sub-heading">How can I help you?</h2>         
        </header>
        <ul class="suggestions">
            <li class="suggestions-item">
                <p class="text">Design a home office setup for remote work under %500.</p>
                <span class="material-symbols-rounded">draw</span>
            </li>
            <li class="suggestions-item">
                <p class="text">How can I level up my web development expertise in 2025?</p>
                <span class="material-symbols-rounded">lightbulb</span>
            </li>
            <li class="suggestions-item">
                <p class="text">Suggest some useful tools for debugging JavaScript code.</p>
                <span class="material-symbols-rounded">explore</span>
            </li>
            <li class="suggestions-item">
                <p class="text">Create a React JS component for the simple todo list app.</p>
                <span class="material-symbols-rounded">code_blocks</span>
            </li>
        </ul>

        <div class="chats-container"></div>

        <div class="prompt-container">
            <div class="prompt-wrapper">
                <form action="#" class="prompt-form">
                    <input type="text" placeholder="Ask Manucian" class="prompt-input" required>
                    <div class="prompt-actions">
                        <!--<button id="add-file-btn" class="material-symbols-rounded">attach_file</button>-->
                        <button id="send-prompts-btn" class="material-symbols-rounded">arrow_upward</button>
                    </div>
                </form>
            </div>
            
            <p class="disclaimer-text">Our AI can make mistakes, so double-check it.</p>
        </div>
    </div>
</main>

    <script src="script.js"></script>
</body>
</html>
